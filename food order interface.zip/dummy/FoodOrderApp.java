import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FoodOrderApp extends JFrame implements ActionListener {
    private JComboBox<String> cbItems;
    private JTextField txtQuantity;
    private JButton btnAdd, btnClear, btnExit, btnOrder;
    private JTextArea txtSelectedItems;
    private JLabel lblPrice, lblTotalPrice;
    private double totalPrice;
    private String[] items = { "Pizza", "Burger", "Hotdog", "Sandwich", "Bajji" };
    private double[] prices = { 10.0, 5.0, 3.0, 7.0, 1.0 };

    public FoodOrderApp() {
        // set window title and size
        setTitle("Food Order App");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // create panels
        JPanel panel1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JPanel panel2 = new JPanel(new GridLayout(1, 2));
        JPanel panel3 = new JPanel(new BorderLayout());
        JPanel panel4 = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        // create components
        JLabel lblItem = new JLabel("Select Item:");
        cbItems = new JComboBox<>(items);
        cbItems.setSelectedIndex(0);
        JLabel lblQuantity = new JLabel("Enter Quantity:");
        txtQuantity = new JTextField(5);
        lblPrice = new JLabel("Price: $" + prices[0]);
        btnAdd = new JButton("Add");
        btnAdd.addActionListener(this);
        btnClear = new JButton("Clear");
        btnClear.addActionListener(this);
        btnExit = new JButton("Exit");
        btnExit.addActionListener(this);
        txtSelectedItems = new JTextArea(10, 30);
        txtSelectedItems.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(txtSelectedItems);
        lblTotalPrice = new JLabel("Total Price: $0.00");
        btnOrder = new JButton("Place Order");
        btnOrder.addActionListener(this);

        // add components to panels
        panel1.add(lblItem);
        panel1.add(cbItems);
        panel1.add(lblQuantity);
        panel1.add(txtQuantity);
        panel1.add(lblPrice);
        panel1.add(btnAdd);
        panel1.add(btnClear);
        panel2.add(scrollPane);
        panel2.add(lblTotalPrice);
        panel4.add(btnOrder);
        panel4.add(btnExit);

        // add panels to window
        add(panel1, BorderLayout.NORTH);
        add(panel2, BorderLayout.CENTER);
        add(panel3, BorderLayout.SOUTH);
        panel3.add(panel4, BorderLayout.EAST);

        // center window on screen
        setLocationRelativeTo(null);

        // set colors
        panel1.setBackground(Color.white);
        panel2.setBackground(Color.white);
        panel3.setBackground(Color.white);
        panel4.setBackground(Color.white);
        lblItem.setForeground(Color.blue);
        lblQuantity.setForeground(Color.blue);
        lblPrice.setForeground(Color.blue);
        lblTotalPrice.setForeground(Color.blue);
        txtSelectedItems.setBackground(Color.lightGray);
        txtSelectedItems.setForeground(Color.BLACK);
        txtSelectedItems.setFont(new Font("Courier New", Font.PLAIN, 18));
        btnAdd.setBackground(Color.green);
        btnClear.setBackground(Color.red);
        btnOrder.setBackground(Color.blue);
        btnExit.setBackground(Color.gray);
        btnAdd.setForeground(Color.white);
        btnClear.setForeground(Color.white);
        btnOrder.setForeground(Color.white);
        btnExit.setForeground(Color.white);

        // show window
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
            


        
        
        
        
        if (e.getSource() == btnAdd) {
            int index = cbItems.getSelectedIndex();
            String itemName = items[index];

            int quantity;
            try {
                quantity = Integer.parseInt(txtQuantity.getText());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid quantity.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (quantity <= 0) {
                JOptionPane.showMessageDialog(this, "Please enter a valid quantity.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            double price = prices[index];
            double itemPrice = price * quantity;
            totalPrice += itemPrice;
            String selected = itemName + " x " + quantity + " = $" + itemPrice;
            txtSelectedItems.append(selected + "\n");
            lblTotalPrice.setText("Total Price: $" + String.format("%.2f", totalPrice));

            // clear inputs
            cbItems.setSelectedIndex(0);
            txtQuantity.setText("");
            lblPrice.setText("Price: $" + String.format("%.2f", prices[0]));

        } else if (e.getSource() == btnClear) {
            // clear all inputs and outputs
            cbItems.setSelectedIndex(0);
            txtQuantity.setText("");
            lblPrice.setText("Price: $" + String.format("%.2f", prices[0]));
        } else if (e.getSource() == btnOrder) {
            // show order confirmation message and clear all inputs and outputs
            if (totalPrice == 0) {
                JOptionPane.showMessageDialog(this, "No items added to the order.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to place the order?\nTotal Price: $" + String.format("%.2f", totalPrice));
            if (confirm == JOptionPane.YES_OPTION) {
                JOptionPane.showMessageDialog(this,
                        "Order placed successfully!\nTotal Price: $" + String.format("%.2f", totalPrice));
                cbItems.setSelectedIndex(0);
                txtQuantity.setText("");
                lblPrice.setText("Price: $" + String.format("%.2f", prices[0]));
                txtSelectedItems.setText("");
                lblTotalPrice.setText("Total Price: $0.00");
                totalPrice = 0.0;
            }

        } else if (e.getSource() == btnExit) {
            // exit the application
            System.exit(0);

        } else if (e.getSource() == cbItems) {
            // update the item price when a different item is selected
            int index = cbItems.getSelectedIndex();
            double price = prices[index];
            lblPrice.setText("Price: $" + String.format("%.2f", price));
        }
        
    }

    public static void main(String[] args) {
        FoodOrderApp app = new FoodOrderApp();
        app.getContentPane().setBackground(Color.LIGHT_GRAY);
    }

}